// screens/customer/PickupCartScreen.js
import React, { useContext, useMemo, useState, useCallback } from "react";
import {
	View,
	Text,
	StyleSheet,
	SafeAreaView,
	FlatList,
	TouchableOpacity,
} from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { useTranslation } from "react-i18next";
import colors from "../../utils/styles/appStyles";
import { useParty } from "../../context/customer/PartyContext";
import { AuthContext } from "../../context/authContext";
import OrderItemCard from "../../components/customer/OrderItemCard";
import formatCurrency from "../../utils/currencyFormatter";

const PickupCartScreen = () => {
	const { t } = useTranslation();
	const navigation = useNavigation();
	const route = useRoute();
	const { currentUserData } = useContext(AuthContext);

	const { sharedBaskets, handlePartyItemQuantityChange } = useParty();
	const currentPartyId = route.params?.partyId;

	const [updatingItemId, setUpdatingItemId] = useState(null);

	const myItems = useMemo(() => {
		if (!sharedBaskets || !currentPartyId || !currentUserData?.uid) return [];
		const rawBasket = sharedBaskets[currentPartyId] || {};
		const items = rawBasket.items || [];
		return items.filter(
			(item) =>
				item.addedByUserId === currentUserData.uid ||
				item.orderedByUserId === currentUserData.uid,
		);
	}, [sharedBaskets, currentPartyId, currentUserData?.uid]);

	const subtotal = useMemo(() => {
		return myItems.reduce((total, item) => {
			const itemPrice =
				item.discountedPrice !== null && item.discountedPrice !== undefined
					? item.discountedPrice
					: item.price;
			return total + itemPrice * (item.quantity || 1);
		}, 0);
	}, [myItems]);

	const onQuantityChange = useCallback(
		async (itemId, newQuantity) => {
			if (!currentPartyId || !currentUserData?.uid) return;
			setUpdatingItemId(itemId);
			try {
				await handlePartyItemQuantityChange(
					currentPartyId,
					itemId,
					newQuantity,
					currentUserData.uid,
				);
			} catch (error) {
				console.error("Item Update Error", error);
			} finally {
				setUpdatingItemId(null);
			}
		},
		[currentPartyId, currentUserData?.uid, handlePartyItemQuantityChange],
	);

	return (
		<SafeAreaView style={styles.screen}>
			<View style={styles.headerBar}>
				<TouchableOpacity
					onPress={() => navigation.goBack()}
					style={styles.backButton}
				>
					<Ionicons name="arrow-back" size={24} color={colors.textDark} />
				</TouchableOpacity>
				<Text style={styles.headerTitle}>
					{t("pickup_order", "Pickup Order")}
				</Text>
				<View style={{ width: 24 }} />
			</View>

			<FlatList
				data={myItems}
				keyExtractor={(item, index) => item.id || `basket-item-${index}`}
				contentContainerStyle={styles.listContent}
				ListEmptyComponent={
					<View style={styles.emptyContainer}>
						<MaterialCommunityIcons
							name="shopping-outline"
							size={60}
							color={colors.textLight}
						/>
						<Text style={styles.emptyText}>
							{t("your_cart_is_empty", "Your cart is empty.")}
						</Text>
					</View>
				}
				renderItem={({ item, index }) => {
					const isLastItem = index === myItems.length - 1;
					return (
						<View
							style={[
								styles.itemContainer,
								!isLastItem && styles.itemSeparator,
							]}
						>
							<OrderItemCard
								item={item}
								onQuantityChange={onQuantityChange}
								allowEdit={true}
								isUpdating={updatingItemId === item.id}
							/>
						</View>
					);
				}}
			/>

			{myItems.length > 0 && (
				<View style={styles.stickyBottomBar}>
					<View style={styles.subtotalRow}>
						<Text style={styles.subtotalLabel}>
							{t("subtotal", "Subtotal")}
						</Text>
						<Text style={styles.subtotalAmount}>
							{formatCurrency(subtotal * 100)}
						</Text>
					</View>

					<View style={styles.stickySplitRow}>
						<TouchableOpacity
							style={styles.stickySecondaryBtn}
							onPress={() => navigation.goBack()}
						>
							<Text style={styles.stickySecondaryBtnText}>
								+ {t("add_more", "Add More")}
							</Text>
						</TouchableOpacity>

						<TouchableOpacity
							style={styles.stickyPrimaryBtn}
							onPress={() =>
								navigation.navigate("PartyCheckout", {
									partyId: currentPartyId,
								})
							}
						>
							<Text style={styles.stickyPrimaryBtnText}>
								{t("checkout", "Checkout")}
							</Text>
							<Ionicons
								name="arrow-forward"
								size={20}
								color="#FFF"
								style={{ marginLeft: 8 }}
							/>
						</TouchableOpacity>
					</View>
				</View>
			)}
		</SafeAreaView>
	);
};

const styles = StyleSheet.create({
	screen: { flex: 1, backgroundColor: colors.backgroundLight },
	headerBar: {
		flexDirection: "row",
		justifyContent: "space-between",
		alignItems: "center",
		paddingVertical: 15,
		paddingHorizontal: 15,
		backgroundColor: colors.surfaceWhite,
		borderBottomWidth: 1,
		borderBottomColor: colors.borderLight,
	},
	backButton: { padding: 5 },
	headerTitle: { fontSize: 18, fontWeight: "bold", color: colors.textDark },
	listContent: { padding: 15, paddingBottom: 120 },
	itemContainer: { paddingVertical: 4 },
	itemSeparator: {
		borderBottomWidth: 1,
		borderBottomColor: colors.borderLight,
		marginBottom: 8,
		paddingBottom: 8,
	},
	emptyContainer: {
		alignItems: "center",
		justifyContent: "center",
		marginTop: 80,
	},
	emptyText: { marginTop: 15, fontSize: 16, color: colors.textMedium },

	stickyBottomBar: {
		position: "absolute",
		bottom: 0,
		left: 0,
		right: 0,
		backgroundColor: colors.surfaceWhite,
		paddingHorizontal: 20,
		paddingTop: 15,
		paddingBottom: 30,
		borderTopWidth: 1,
		borderTopColor: colors.borderLight,
		shadowColor: "#000",
		shadowOffset: { width: 0, height: -3 },
		shadowOpacity: 0.1,
		shadowRadius: 5,
		elevation: 10,
	},
	subtotalRow: {
		flexDirection: "row",
		justifyContent: "space-between",
		marginBottom: 15,
	},
	subtotalLabel: { fontSize: 16, color: colors.textMedium, fontWeight: "600" },
	subtotalAmount: { fontSize: 18, color: colors.textDark, fontWeight: "bold" },
	stickySplitRow: { flexDirection: "row", gap: 15 },
	stickySecondaryBtn: {
		flex: 1,
		justifyContent: "center",
		alignItems: "center",
		paddingVertical: 14,
		borderRadius: 12,
		backgroundColor: colors.backgroundLight,
		borderWidth: 1,
		borderColor: colors.borderLight,
	},
	stickySecondaryBtnText: {
		color: colors.textDark,
		fontSize: 16,
		fontWeight: "600",
	},
	stickyPrimaryBtn: {
		flex: 2,
		flexDirection: "row",
		justifyContent: "center",
		alignItems: "center",
		paddingVertical: 14,
		borderRadius: 12,
		backgroundColor: colors.primary,
	},
	stickyPrimaryBtnText: {
		color: colors.surfaceWhite,
		fontSize: 16,
		fontWeight: "bold",
	},
});

export default PickupCartScreen;
