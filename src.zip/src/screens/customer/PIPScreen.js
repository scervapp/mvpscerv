import React, { useContext, useEffect, useState } from "react";

import {
	View,
	Text,
	FlatList,
	TextInput,
	StyleSheet,
	TouchableOpacity,
	Alert,
	Platform,
	ActivityIndicator,
	Modal,
	SafeAreaView,
} from "react-native";
import { AuthContext } from "../../context/authContext";

import { db, functions } from "../../config/firebase";
import { Ionicons } from "@expo/vector-icons";
import colors from "../../utils/styles/appStyles";
import { httpsCallable } from "@react-native-firebase/functions";
import { useTranslation } from "react-i18next";
// Creating a pips screen that allows customers to create pips using firestore
// and the pips go into the customers collection / uid/ pips
const PIPSListScreen = () => {
	const { t } = useTranslation();
	// Get auth context
	const { currentUserData } = useContext(AuthContext);
	const [newPipName, setNewPipName] = useState("");
	const [pips, setPIPs] = useState([]);
	const [isLoading, setIsLoading] = useState(true);

	// --- State for User Search Modal ---
	const [isSearchModalVisible, setIsSearchModalVisible] = useState(false);
	const [searchTerm, setSearchTerm] = useState("");
	const [searchResults, setSearchResults] = useState([]);
	const [isSearching, setIsSearching] = useState(false);
	const [searchError, setSearchError] = useState(null);
	// --- End Search Modal State ---

	// --- Cloud Function Reference ---
	const searchPIPsFunction = httpsCallable(functions, "searchPIPs");
	// --- End CF Reference ---

	// Create a new pip
	const createNewPip = async () => {
		if (!newPipName) {
			return;
		}
		try {
			const pipsRef = db
				.collection("customers")
				.doc(currentUserData.uid)
				.collection("pips");
			await addDoc(pipsRef, {
				name: newPipName,
			});
			setNewPipName("");
		} catch (error) {
			console.log("Error adding pips", error);
		}
	};

	useEffect(() => {
		if (!currentUserData?.uid) {
			setIsLoading(false);
			return; // Don't do anything if we don't have a user ID
		}

		setIsLoading(true); // Set loading true when we start fetching

		const pipsQuery = db
			.collection("customers")
			.doc(currentUserData.uid)
			.collection("pips")
			.orderBy("name");

		const unsubscribe = pipsQuery.onSnapshot(
			(snapshot) => {
				const pipsList = snapshot.docs.map((doc) => ({
					id: doc.id,
					...doc.data(),
				}));
				setPIPs(pipsList);
				setIsLoading(false); // Set loading to false once we have the data
			},
			(error) => {
				console.error("Error fetching PIPs:", error);
				Alert.alert(t("error"), t("could_not_load_your_pips"));
				setIsLoading(false); // Also stop loading on error
			}
		);

		// This is the cleanup function that runs when the component unmounts
		return () => unsubscribe();
	}, [currentUserData?.uid]);

	const handleDeletePip = async (pipId) => {
		Alert.alert(
			t("confirm_delete"),
			t("are_you_sure_you_want_to_delete_this_pip"),
			[
				{ text: t("cancel"), style: "cancel" },
				{
					text: t("delete"),
					style: "destructive",
					onPress: async () => {
						try {
							// --- REFACTORED FIRESTORE DELETE ---
							await db
								.collection("customers")
								.doc(currentUserData.uid)
								.collection("pips")
								.doc(pipId)
								.delete();
							setPIPs(pips.filter((pip) => pip.id !== pipId));
						} catch (error) {
							console.error("Error deleting PIP:", error);
							Alert.alert(t("error"), t("failed_to_delete_pip"));
						}
					},
				},
			]
		);
	};

	const fetchPIPS = async () => {
		const pipsRef = collection(db, `customers/${currentUserData.uid}/pips`);
		const q = query(pipsRef, orderBy("name"));
		const unsubscribe = onSnapshot(q, (querySnapshot) => {
			const pipsArray = querySnapshot.docs.map((doc) => ({
				id: doc.id,
				...doc.data(),
			}));
			setPIPs(pipsArray);
		});
		return () => unsubscribe();
	};

	// fetch pips from db
	const usePIPsListener = (currentUserData) => {
		const [pips, setPIPs] = useState([]);
		const [isLoading, setIsLoading] = useState(true);

		useEffect(() => {
			if (!currentUserData?.uid) {
				setIsLoading(false);
				setPIPs([]);
				return;
			}
			setIsLoading(true);

			// --- REFACTORED FIRESTORE LISTENER ---
			const pipsQuery = db
				.collection(`customers/${currentUserData.uid}/pips`)
				.orderBy("name");

			const unsubscribe = pipsQuery.onSnapshot(
				(snapshot) => {
					const pipsList = snapshot.docs.map((doc) => ({
						id: doc.id,
						...doc.data(),
					}));
					setPIPs(pipsList);
					setIsLoading(false);
				},
				(error) => {
					console.error("Error fetching PIPs:", error);
					Alert.alert(t("error"), t("could_not_load_your_pips"));
					setIsLoading(false);
				}
			);

			return () => unsubscribe();
		}, [currentUserData?.uid]);

		return { pips, setPIPs, isLoading };
	};

	const handleAddPip = async () => {
		if (newPipName.trim() === "" || !currentUserData?.uid) return;
		try {
			// --- REFACTORED FIRESTORE ADD ---
			const pipsRef = db.collection(`customers/${currentUserData.uid}/pips`);
			await pipsRef.add({
				name: newPipName.trim(),
				isUser: false,
				addedAt: new Date(),
			});
			setNewPipName("");
		} catch (error) {
			console.error("Error adding placeholder PIP:", error);
			Alert.alert(t("error"), t("could_not_add_pip"));
		}
	};

	const handleSearchPIPs = async (
		searchTerm,
		currentUserData,
		setSearchResults,
		setSearchError,
		setIsSearching
	) => {
		if (searchTerm.trim().length < 3) {
			setSearchError(t("search_term_must_be_at_least_3_characters"));
			setSearchResults([]);
			return;
		}
		setIsSearching(true);
		setSearchError(null);
		setSearchResults([]);
		try {
			// This was already using the correct native functions API
			const searchPIPsFunction = httpsCallable(functions, "searchPIPs");
			const result = await searchPIPsFunction({
				searchTerm: searchTerm.trim(),
			});

			if (result.data.success && result.data.users) {
				const filteredResults = result.data.users.filter(
					(user) => user.id !== currentUserData?.uid
				);
				setSearchResults(filteredResults);
				if (filteredResults.length === 0) {
					setSearchError(t("no_matching_users_found"));
				}
			} else {
				throw new Error(result.data.error || t("search_failed"));
			}
		} catch (error) {
			console.error("Error searching users:", error);
			setSearchError(error.message || t("an_error_occurred_during_search"));
		} finally {
			setIsSearching(false);
		}
	};

	// --- NEW: Handle Adding a User PIP ---
	const handleAddUserPip = async (
		currentUserData,
		pips,
		userToAdd,
		setIsSearchModalVisible
	) => {
		if (!currentUserData?.uid || !userToAdd?.id || !userToAdd?.name) return;

		const alreadyExists = pips.some(
			(pip) => pip.isUser && pip.userId === userToAdd.id
		);
		if (alreadyExists) {
			Alert.alert(t("info"), `${userToAdd.name} ${t("is_already_in_your_pips_list")}`);
			return;
		}

		setIsSearchModalVisible(false);

		try {
			// --- REFACTORED FIRESTORE ADD ---
			const pipsRef = db.collection(`customers/${currentUserData.uid}/pips`);
			await pipsRef.add({
				name: userToAdd.name,
				userId: userToAdd.id,
				isUser: true,
				addedAt: new Date(),
			});
			Alert.alert(t("success"), `${userToAdd.name} ${t("added_to_your_pips")}`);
		} catch (error) {
			console.error("Error adding user PIP:", error);
			Alert.alert(t("error"), `${t("could_not_add")} ${userToAdd.name} ${t("to_pips")}`);
		}
	};

	// Fucntion to render an individual PIP
	const renderPip = ({ item }) => (
		<View style={styles.pipItem}>
			<Ionicons name="person-circle-outline" size={24} color="gray" />
			<Text style={styles.pipName}>{item.name}</Text>
			<TouchableOpacity onPress={() => handleDeletePip(item.id)}>
				<Ionicons name="trash-outline" size={24} color={"red"} />
				{/* Use a trash icon */}
			</TouchableOpacity>
		</View>
	);

	// --- Render Item (Modified) ---
	const renderPipItem = ({ item }) => (
		<View style={styles.pipItem}>
			<Ionicons
				name={item.isUser ? "person-circle" : "person-add-outline"} // Different icons
				size={24}
				color={item.isUser ? colors.primary : colors.textDark} // Different colors
				style={styles.pipIcon}
			/>
			<Text style={styles.pipName}>{item.name}</Text>
			<TouchableOpacity onPress={() => handleDeletePip(item.id)}>
				<Ionicons name="trash-outline" size={24} color={"red"} />
			</TouchableOpacity>
		</View>
	);

	return (
		<View style={styles.container}>
			<Text style={styles.instructions}>
				{t(
					"create_a_local_pip_for_your_personal_party_or_search_for_other_scerv_users_to_add_them"
				)}
			</Text>
			{/* Input for adding placeholder PIPs (Existing) */}
			<View style={styles.addPipContainer}>
				<TextInput
					style={styles.input}
					placeholder={t("enter_local_pip_name")}
					value={newPipName}
					onChangeText={setNewPipName}
					placeholderTextColor={colors.textMedium}
				/>
				<TouchableOpacity style={styles.addButton} onPress={handleAddPip}>
					<Text style={styles.addButtonText}>{t("add_local_pip")}</Text>
				</TouchableOpacity>
			</View>

			{/* --- Button to Add User PIP --- */}
			<TouchableOpacity
				style={[styles.addButton, styles.addUserButton]} // Different style
				onPress={() => setIsSearchModalVisible(true)}
			>
				<Ionicons
					name="search-outline"
					size={18}
					color="white"
					style={{ marginRight: 5 }}
				/>
				<Text style={styles.addButtonText}>{t("find_add_user_pip")}</Text>
			</TouchableOpacity>
			{/* --- End Button --- */}

			{/* List of PIPs */}
			{isLoading ? (
				<ActivityIndicator size="large" color={colors.primary} />
			) : (
				<FlatList
					data={pips}
					renderItem={renderPipItem}
					keyExtractor={(item) => item.id}
					ListEmptyComponent={
						<Text style={styles.emptyText}>{t("no_pips_added_yet")}</Text>
					}
				/>
			)}

			{/* --- User Search Modal --- */}
			<Modal
				visible={isSearchModalVisible}
				animationType="slide"
				onRequestClose={() => setIsSearchModalVisible(false)}
			>
				<SafeAreaView style={styles.modalContainer}>
					<View style={styles.modalHeader}>
						<Text style={styles.modalTitle}>{t("find_user_pip")}</Text>
						<TouchableOpacity onPress={() => setIsSearchModalVisible(false)}>
							<Ionicons
								name="close-circle"
								size={30}
								color={colors.textLight}
							/>
						</TouchableOpacity>
					</View>
					<View style={styles.searchContainer}>
						<TextInput
							style={styles.searchInput}
							placeholder={t("search_by_email_or_name")}
							value={searchTerm}
							onChangeText={setSearchTerm}
							autoCapitalize="none"
							autoCorrect={false}
							placeholderTextColor={colors.textMedium}
						/>
						<TouchableOpacity
							style={[
								styles.searchButton,
								isSearching && styles.disabledButton,
							]}
							onPress={handleSearchPIPs}
							disabled={isSearching}
						>
							{isSearching ? (
								<ActivityIndicator color="white" size="small" />
							) : (
								<Text style={styles.searchButtonText}>{t("search")}</Text>
							)}
						</TouchableOpacity>
					</View>

					{searchError && (
						<Text style={styles.errorTextModal}>{searchError}</Text>
					)}

					<FlatList
						data={searchResults}
						keyExtractor={(item) => item.id}
						renderItem={({ item }) => (
							<TouchableOpacity
								style={styles.searchResultItem}
								onPress={() => handleAddUserPip(item)}
							>
								<Ionicons
									name="person-circle-outline"
									size={24}
									color={colors.primary}
									style={styles.pipIcon}
								/>
								<Text style={styles.searchResultName}>{item.name}</Text>
								{/* Optionally show email: <Text style={styles.searchResultEmail}>{item.email}</Text> */}
								<Ionicons
									name="add-circle-outline"
									size={26}
									color={colors.success}
								/>
							</TouchableOpacity>
						)}
						ListEmptyComponent={
							!isSearching && !searchError ? (
								<Text style={styles.emptyText}>
									{t("enter_search_term_above")}
								</Text>
							) : null
						}
					/>
				</SafeAreaView>
			</Modal>
			{/* --- End Search Modal --- */}
		</View>
	);
};

// Stylesheet
const styles = StyleSheet.create({
	instructions: {
		textAlign: "center",
		marginBottom: 15,
		fontSize: 14,
		color: colors.textMedium,
	},
	container: {
		flex: 1,
		padding: 15,
		backgroundColor: colors.background,
	},
	addPipContainer: {
		flexDirection: "row",
		marginBottom: 15,
		alignItems: "center",
	},
	input: {
		flex: 1,
		borderWidth: 1,
		borderColor: colors.mediumGray || "#ccc",
		padding: 10,
		borderRadius: 8,
		marginRight: 10,
		backgroundColor: "white",
		color: colors.textDark,
	},
	addButton: {
		backgroundColor: colors.primary,
		paddingVertical: 10,
		paddingHorizontal: 12,
		borderRadius: 8,
		flexDirection: "row",
		alignItems: "center",
	},
	addUserButton: {
		// Style for the second button
		backgroundColor: colors.secondary || "#5a6268",
		marginBottom: 20, // Space below this button
		justifyContent: "center",
	},
	addButtonText: {
		color: "white",
		fontWeight: "bold",
	},
	pipItem: {
		flexDirection: "row",
		justifyContent: "space-between",
		alignItems: "center",
		padding: 15,
		backgroundColor: "white",
		borderRadius: 8,
		marginBottom: 10,
		shadowColor: "#000",
		shadowOffset: { width: 0, height: 1 },
		shadowOpacity: 0.1,
		shadowRadius: 2,
		elevation: 2,
		color: colors.textDark,
	},
	pipIcon: {
		marginRight: 10,
	},
	pipName: {
		flex: 1,
		fontSize: 16,
		color: colors.textDark,
	},
	emptyText: {
		textAlign: "center",
		marginTop: 30,
		color: colors.textLight,
		fontStyle: "italic",
	},
	// Modal Styles
	modalContainer: {
		flex: 1,
		marginTop: Platform.OS === "ios" ? 40 : 20, // Adjust for status bar
		padding: 15,
	},
	modalHeader: {
		flexDirection: "row",
		justifyContent: "space-between",
		alignItems: "center",
		marginBottom: 20,
	},
	modalTitle: {
		fontSize: 20,
		fontWeight: "bold",
		color: colors.textDark,
	},
	searchContainer: {
		flexDirection: "row",
		marginBottom: 15,
	},
	searchInput: {
		flex: 1,
		borderWidth: 1,
		borderColor: colors.mediumGray || "#ccc",
		padding: 10,
		borderRadius: 8,
		marginRight: 10,
		backgroundColor: "white",
		color: colors.textDark,
	},
	searchButton: {
		backgroundColor: colors.primary,
		paddingVertical: 10,
		paddingHorizontal: 15,
		borderRadius: 8,
		justifyContent: "center",
	},
	searchButtonText: {
		color: "white",
		fontWeight: "bold",
	},
	searchResultItem: {
		flexDirection: "row",
		alignItems: "center",
		padding: 15,
		backgroundColor: "white",
		borderRadius: 8,
		marginBottom: 10,
		borderWidth: 1,
		borderColor: colors.lightGray || "#eee",
	},
	searchResultName: {
		flex: 1,
		fontSize: 16,
	},
	errorTextModal: {
		color: colors.danger,
		textAlign: "center",
		marginBottom: 10,
	},
	disabledButton: {
		backgroundColor: colors.mediumGray || "#cccccc",
		opacity: 0.7,
	},
});

export default PIPSListScreen;
