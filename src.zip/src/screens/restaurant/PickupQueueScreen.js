// screens/restaurant/PickupQueueScreen.js
import React, { useState, useEffect, useContext } from "react";
import {
	View,
	Text,
	StyleSheet,
	SafeAreaView,
	FlatList,
	TouchableOpacity,
	ActivityIndicator,
	Alert,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useTranslation } from "react-i18next";
import moment from "moment";

import colors from "../../utils/styles/appStyles";
import { db } from "../../config/firebase";
import { AuthContext } from "../../context/authContext";

const PickupQueueScreen = () => {
	const { t } = useTranslation();
	const { currentUserData } = useContext(AuthContext);

	const [orders, setOrders] = useState([]);
	const [isLoading, setIsLoading] = useState(true);

	// 1. Real-Time Listener for Hotel Pickup Orders
	useEffect(() => {
		if (!currentUserData?.uid) return;

		const unsubscribe = db
			.collection("kitchen_orders")
			.where("restaurantId", "==", currentUserData.uid)
			.where("overallStatus", "==", "active")
			.where("fulfillmentType", "==", "hotel_pickup")
			.onSnapshot((snap) => {
				if (!snap) return;

				const fetchedOrders = snap.docs.map((doc) => ({
					id: doc.id,
					...doc.data(),
				}));

				// Sort locally by oldest first so the longest-waiting guest is at the top
				fetchedOrders.sort((a, b) => {
					const timeA = a.createdAt?.toMillis() || 0;
					const timeB = b.createdAt?.toMillis() || 0;
					return timeA - timeB;
				});

				setOrders(fetchedOrders);
				setIsLoading(false);
			});

		return () => unsubscribe();
	}, [currentUserData?.uid]);

	// 2. The Final Handoff Action
	const handleHandOff = async (order) => {
		Alert.alert(
			t("confirm_handoff", "Confirm Handoff"),
			t(
				"handoff_message",
				"Has this order been handed to the guest or the runner?",
			),
			[
				{ text: t("cancel", "Cancel"), style: "cancel" },
				{
					text: t("confirm", "Confirm"),
					style: "default",
					onPress: async () => {
						try {
							// A. Remove from the FOH Queue
							await db.collection("kitchen_orders").doc(order.id).update({
								overallStatus: "completed",
								status: "completed",
								completedAt: new Date().toISOString(),
							});

							// B. Force the Customer's Tracker to "Completed" to show the rating screen
							// Note: We use order.id assuming your backend syncs identical IDs,
							// or fallback to pendingOrderId if you stored it.
							const customerTrackingId = order.pendingOrderId || order.id;

							await db
								.collection("pending_orders")
								.doc(customerTrackingId)
								.update({
									status: "completed",
								});
						} catch (error) {
							console.error("Error closing out pickup order:", error);
							Alert.alert("Error", "Could not close out the order. Try again.");
						}
					},
				},
			],
		);
	};

	// 3. Render Individual Bags/Orders
	const renderOrderItem = ({ item }) => {
		// Determine what the kitchen is currently doing
		const kitchenStatus = item.stationStatuses?.kitchen || item.status || "new";

		let statusText = t("pending", "Waiting on Kitchen");
		let statusColor = colors.statusWarning; // Orange
		let isReady = false;

		if (kitchenStatus === "preparing") {
			statusText = t("cooking", "Kitchen Preparing");
			statusColor = colors.primary; // Blue
		} else if (kitchenStatus === "ready") {
			statusText = t("ready_for_pickup", "READY FOR PICKUP");
			statusColor = colors.statusSuccess; // Green
			isReady = true;
		}

		const waitTime = item.createdAt
			? moment(item.createdAt.toDate()).fromNow(true)
			: "Just now";

		return (
			<View style={[styles.orderCard, isReady && styles.orderCardReady]}>
				<View style={styles.cardHeader}>
					<View>
						<Text style={styles.orderTitle}>
							{item.table?.name || item.locationName || "Hotel Guest"}
						</Text>
						<Text style={styles.orderSubtitle}>
							{item.items?.length || 0} items • {t("waiting", "Waiting:")}{" "}
							{waitTime}
						</Text>
					</View>
					<View
						style={[
							styles.statusBadge,
							{ backgroundColor: statusColor + "20" },
						]}
					>
						<Text style={[styles.statusText, { color: statusColor }]}>
							{statusText.toUpperCase()}
						</Text>
					</View>
				</View>

				<View style={styles.itemsList}>
					{item.items?.map((dish, index) => (
						<Text key={index} style={styles.itemText} numberOfLines={1}>
							<Text style={styles.itemQuantity}>{dish.quantity}x</Text>{" "}
							{dish.dishName || dish.name}
						</Text>
					))}
				</View>

				<TouchableOpacity
					style={[
						styles.handoffButton,
						!isReady && styles.handoffButtonDisabled,
					]}
					onPress={() => handleHandOff(item)}
				>
					<Ionicons
						name={isReady ? "checkmark-circle" : "time-outline"}
						size={20}
						color={isReady ? "#FFF" : colors.textMedium}
					/>
					<Text
						style={[
							styles.handoffButtonText,
							!isReady && { color: colors.textMedium },
						]}
					>
						{t("mark_as_handed_off", "Mark as Handed Off")}
					</Text>
				</TouchableOpacity>
			</View>
		);
	};

	return (
		<SafeAreaView style={styles.container}>
			<View style={styles.header}>
				<Ionicons name="bag-handle" size={28} color={colors.primary} />
				<Text style={styles.title}>{t("pickup_queue", "Pickup Queue")}</Text>

				{/* Small counter pill */}
				{!isLoading && orders.length > 0 && (
					<View style={styles.counterPill}>
						<Text style={styles.counterText}>{orders.length}</Text>
					</View>
				)}
			</View>

			{isLoading ? (
				<View style={styles.centerContent}>
					<ActivityIndicator size="large" color={colors.primary} />
				</View>
			) : (
				<FlatList
					data={orders}
					keyExtractor={(item) => item.id}
					renderItem={renderOrderItem}
					contentContainerStyle={styles.listContent}
					ListEmptyComponent={
						<View style={styles.centerContent}>
							<Ionicons
								name="checkmark-done-circle"
								size={80}
								color="#E2E8F0"
							/>
							<Text style={styles.placeholderText}>
								{t("no_pickup_orders", "No active pickup orders right now.")}
							</Text>
						</View>
					}
				/>
			)}
		</SafeAreaView>
	);
};

const styles = StyleSheet.create({
	container: { flex: 1, backgroundColor: colors.backgroundLight || "#F8FAFC" },
	header: {
		flexDirection: "row",
		alignItems: "center",
		padding: 20,
		backgroundColor: "#FFF",
		borderBottomWidth: 1,
		borderBottomColor: "#E2E8F0",
	},
	title: {
		fontSize: 24,
		fontWeight: "bold",
		color: colors.textDark,
		marginLeft: 10,
	},
	counterPill: {
		backgroundColor: colors.statusDanger,
		paddingHorizontal: 10,
		paddingVertical: 4,
		borderRadius: 12,
		marginLeft: 12,
	},
	counterText: {
		color: "#FFF",
		fontWeight: "bold",
		fontSize: 14,
	},
	centerContent: {
		flex: 1,
		justifyContent: "center",
		alignItems: "center",
		padding: 20,
	},
	placeholderText: {
		fontSize: 16,
		color: colors.textMedium,
		marginTop: 15,
		fontWeight: "600",
	},
	listContent: {
		padding: 15,
		paddingBottom: 100,
	},
	orderCard: {
		backgroundColor: "#FFF",
		borderRadius: 12,
		padding: 15,
		marginBottom: 15,
		borderWidth: 1,
		borderColor: "#E2E8F0",
		shadowColor: "#000",
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.05,
		shadowRadius: 4,
		elevation: 2,
	},
	orderCardReady: {
		borderColor: colors.statusSuccess,
		borderLeftWidth: 6,
	},
	cardHeader: {
		flexDirection: "row",
		justifyContent: "space-between",
		alignItems: "flex-start",
		marginBottom: 15,
		borderBottomWidth: 1,
		borderBottomColor: "#F1F5F9",
		paddingBottom: 15,
	},
	orderTitle: {
		fontSize: 18,
		fontWeight: "bold",
		color: colors.textDark,
	},
	orderSubtitle: {
		fontSize: 14,
		color: colors.textMedium,
		marginTop: 4,
	},
	statusBadge: {
		paddingHorizontal: 10,
		paddingVertical: 6,
		borderRadius: 8,
	},
	statusText: {
		fontSize: 11,
		fontWeight: "900",
		letterSpacing: 0.5,
	},
	itemsList: {
		marginBottom: 15,
	},
	itemText: {
		fontSize: 15,
		color: colors.textDark,
		marginBottom: 6,
	},
	itemQuantity: {
		fontWeight: "bold",
		color: colors.primary,
	},
	handoffButton: {
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "center",
		backgroundColor: colors.statusSuccess,
		paddingVertical: 12,
		borderRadius: 8,
	},
	handoffButtonDisabled: {
		backgroundColor: "#F1F5F9",
		borderWidth: 1,
		borderColor: "#E2E8F0",
	},
	handoffButtonText: {
		color: "#FFF",
		fontWeight: "bold",
		fontSize: 16,
		marginLeft: 8,
	},
});

export default PickupQueueScreen;
